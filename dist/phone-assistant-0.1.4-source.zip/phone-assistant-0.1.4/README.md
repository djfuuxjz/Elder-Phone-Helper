# 手机助手 · Android MVP

固定目标：在微信中给联系人“女儿”发起视频通话。助手只做读屏、模型判断、高亮和播报；所有微信操作由用户本人完成。

已生成 V0.1.4 测试 APK，136 项应用测试、7 项日志工具测试与严格 lint 通过。小米 15 / 真实微信 / DeepSeek API 尚待安装后验证。详见 [开发进度](docs/PROGRESS.md) 和 [测试报告](docs/TEST_REPORT.md)。

交付文件：`dist/phone-assistant-0.1.4-debug.apk`、`dist/phone-assistant-0.1.4-source.zip`。安装请按 [安装与测试说明](docs/INSTALL_AND_TEST.md)。

新版支持拖动引导栏，点击停止后清除浮层并返回助手。详见 [V0.1.4 修复说明](docs/RELEASE_0.1.4.md)。

## 构建与测试

环境：JDK 17、Android SDK 35、Gradle 8.11.1；项目内已安装的工具可通过下列入口使用：

```sh
sh tools/build-local.sh :app:testDebugUnitTest
sh tools/build-local.sh :app:lintDebug :app:assembleDebug
```

源码包不附带本机工具链或凭据。在另一台电脑安装 JDK 17、Android SDK Platform 35 / Build Tools 35.0.0，设置 `ANDROID_HOME` 或本机 `local.properties` 后运行：

```sh
./gradlew :app:testDebugUnitTest :app:lintDebug :app:assembleDebug
python3 -m unittest discover -s tools -p 'test_*.py' -v
```

首次构建需联网下载固定版本依赖；调试签名在本机生成，不附带签名私钥。安装不同机器重新构建的调试包，签名可能不同，需要先导出日志再卸载旧测试包。

日志和测试报告位于 `docs/test-results`、`app/build/reports/tests`。不设置忽略失败，不通过删除测试让构建变绿。

## 使用准备

1. 在 Android 11 或更高版本手机安装最终交付的 APK。
2. 确认微信已登录，目标联系人明确为“女儿”。与对方约好测试；进入呼叫状态后可立即手动挂断。
3. 打开“我的”，按系统设置指引开启“手机助手 · 操作引导”无障碍服务，再返回 App 确认已连接。
4. 配置 DeepSeek API Key。默认 API 地址为 `https://api.deepseek.com`，默认模型 `deepseek-flash`；如账号使用其他模型，填写实际模型名并按其能力设置图片输入。
5. 在“任务”点击“给女儿打视频电话”，阅读首次提示，开始后助手会直接打开微信。
6. 按高亮和文字/语音逐步操作；可随时停止。

模型能力参考：[DeepSeek 官方图像输入说明](https://api-docs.deepseek.com/guides/vision/)。文档支持不代表当前账号调用已验证，API 错误需以实际运行日志判断。

## 数据与配置

- API Key 使用 Android Keystore 加密后存储，不写入源码、安装包默认值或日志。
- 页面文字和必要截图会发送给用户配置的模型服务。仅启动任务期间采集；停止后停止采集。
- 调试记录保存在应用私有目录，可从 Debug 查看和清理；不是用户历史任务产品。
- 本应用使用独立包名 `cn.elder.assistant`，不覆盖项目目录中的既有 APK。
- 当前没有手机连接、没有模型凭据；真实微信成功率和真实 API 延迟必须由后续真机实测给出。

新版流程库入口：我的 → 流程库 · 开发维护。成功后自动后台复盘保存并启用新版本，人工锁定版受保护；详见 docs/WORKFLOW_LIBRARY.md。
