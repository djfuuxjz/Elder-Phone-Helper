package cn.elder.assistant

import android.os.Handler
import android.os.Looper
import cn.elder.assistant.core.*
import cn.elder.assistant.guidance.*
import cn.elder.assistant.logging.RunNames
import cn.elder.assistant.workflow.*
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import java.nio.file.Files
import java.time.Duration
import java.time.ZoneId

@RunWith(RobolectricTestRunner::class)
class Revision013Test {
    private fun node(id:String,t:String,y:Int=100,kind:String="TextView")=UiNode(id,t,"",kind,true,Box(10,y,400,y+50))
    private fun page(vararg n:UiNode)=Snapshot("s","com.tencent.mm",1,1080,2400,n.toList(),0)
    private fun decision(action:Action=Action.CLICK,id:String?="blank",text:String="请点击搜索")=Decision("search",action,id,null,text,0.9,false,emptyList())
    @Test fun cameraCallFromRealLogCompletesWithoutLiteralVideoLabel() {
        val p=page(node("1","女\u200b儿"),node("2","等待对方接受邀请"),node("3","摄像头已开"),node("4","挂断"))
        assertTrue(CompletionCheck.treeConfirms(p,decision(Action.COMPLETE,null).copy(completed=true)))
        assertFalse(CompletionCheck.treeConfirms(p.copy(nodes=p.nodes.filter { it.id!="3" }+node("5","切换到视频通话")),decision(Action.COMPLETE,null).copy(completed=true)))
    }
    @Test fun answeredVideoCallAlsoCompletesButVoiceDurationDoesNot() {
        val call=page(node("a","00:08"),node("b","摄像头已关"),node("c","挂断"))
        val d=decision(Action.COMPLETE,null).copy(completed=true)
        assertTrue(CompletionCheck.treeConfirms(call,d))
        assertFalse(CompletionCheck.treeConfirms(call.copy(nodes=call.nodes.filter { it.id!="b" }),d))
    }
    @Test fun successVisibleForExactlyOneSecondAndRestartCancelsOldHide() {
        var visible=false;val notice=SuccessNotice(Handler(Looper.getMainLooper()),{visible=true},{visible=false})
        notice.show();shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(999));assertTrue(visible)
        shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(1));assertFalse(visible)
        notice.show();notice.cancel();shadowOf(Looper.getMainLooper()).idleFor(Duration.ofSeconds(2));assertTrue(visible)
    }
    @Test fun inputHighlightsActualEditableField() {
        val blank=node("blank","");val input=node("edit","",200,"android.widget.EditText")
        assertEquals(input.box,WorkflowGuide.target(decision(Action.INPUT),page(blank,input),blank.box,true))
    }
    @Test(expected=IllegalArgumentException::class) fun ambiguousInputsDoNotGuess() { WorkflowGuide.target(decision(Action.INPUT),page(node("a","",100,"EditText"),node("b","",200,"EditText")),null,true) }
    @Test fun blankSearchTargetCorrectedToVisibleSearchControl() {
        val search=node("search","搜索",200);assertEquals(search.box,WorkflowGuide.target(decision(),page(node("blank",""),search),Box(0,300,1000,352),true))
    }
    @Test(expected=IllegalArgumentException::class) fun blankContainerAloneCannotBeSearch() { WorkflowGuide.target(decision(),page(node("blank","")),Box(0,300,1000,352),true) }
    @Test(expected=IllegalStateException::class) fun scrollingContactsIsRejectedWithSpecificReason() { WorkflowGuide.target(decision(Action.SCROLL),page(node("search","搜索")),null,true) }
    @Test fun chatMoreInformationCorrectsToBottomPlus() {
        val plus=node("plus","更多功能",2100);val more=node("more","更多信息",100)
        assertEquals(plus.box,WorkflowGuide.target(decision(id="more",text="点击更多信息"),page(plus,more),more.box,true))
    }
    @Test fun candidatesDoNotReplaceActiveAndRollbackPersists() {
        val store=WorkflowStore(Files.createTempDirectory("flows").resolve("library.json").toFile())
        val id=store.add(WorkflowStore.builtin(),"model","builtin","run_test","去掉绕路")
        assertEquals("builtin",store.selected()!!.getString("id"));assertEquals(id,store.selected(id)!!.getString("id"))
        store.activate(id);assertEquals(id,store.selected()!!.getString("id"));store.activate("builtin");assertEquals("builtin",store.selected()!!.getString("id"))
        store.activate(null);assertNull(store.selected())
    }
    @Test(expected=IllegalArgumentException::class) fun lockedVersionCannotBeEdited() { WorkflowStore(Files.createTempDirectory("flows").resolve("library.json").toFile()).revise("builtin",WorkflowStore.builtin()) }
    @Test(expected=IllegalArgumentException::class) fun unrelatedTaskCannotBeImported() { WorkflowStore.validate(WorkflowStore.builtin().put("task_key","payment")) }
    @Test fun legacyRunExportUsesEventDateAndNewIdsAreUnique() {
        val dir=Files.createTempDirectory("run_old").toFile();java.io.File(dir,"events.jsonl").writeText(JSONObject().put("timestamp",0).toString()+"\n")
        assertEquals(0,RunNames.time(dir));assertEquals("19700101_080000_000",RunNames.stamp(0,ZoneId.of("Asia/Shanghai")))
        assertNotEquals(RunNames.newId(0),RunNames.newId(0));assertTrue(RunNames.exportName(dir).startsWith("debug_"))
    }
}
