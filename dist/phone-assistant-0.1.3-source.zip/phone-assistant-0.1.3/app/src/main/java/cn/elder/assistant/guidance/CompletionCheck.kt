package cn.elder.assistant.guidance

import cn.elder.assistant.core.*

object CompletionCheck {
    fun treeConfirms(s:Snapshot,d:Decision):Boolean {
        if(!d.completed || d.action!=Action.COMPLETE || s.packageName!="com.tencent.mm") return false
        val texts=s.nodes.flatMap { listOf(it.text.trim(),it.description.trim()) }
        val calling=texts.any { it.contains("等待对方") || it.contains("正在呼叫") || it.contains("邀请对方") || it=="通话中" || it.matches(Regex("\\d{1,2}:\\d{2}(?::\\d{2})?")) }
        val video=texts.any { (it.contains("视频通话") && !it.contains("切换到视频")) || it.contains("切换到语音") || it.contains("转换为语音") || it.contains("摄像头已开") || it.contains("摄像头已关") || it.contains("当前为前置摄像头") || it.contains("当前为后置摄像头") }
        val control=texts.any { it=="取消" || it=="挂断" || it=="结束通话" }
        return calling && video && control
    }
    fun visualCandidate(d:Decision):Boolean = d.completed && d.state=="video_call_outgoing" &&
        d.evidence.any { it.contains("等待") || it.contains("呼叫") || it.contains("邀请") } &&
        d.evidence.any { it.contains("视频") || it.contains("语音") }
}
