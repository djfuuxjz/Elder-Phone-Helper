package cn.elder.assistant.workflow

import cn.elder.assistant.core.*
import org.json.JSONObject

object WorkflowGuide {
    fun label(n:UiNode)=listOf(n.text,n.description,n.hint).filter { it.isNotBlank() }.joinToString(" ")
    fun inputs(s:Snapshot)=s.nodes.filter { it.editable || it.kind.endsWith("EditText") }
    fun searches(s:Snapshot)=s.nodes.filter { n -> listOf(n.text,n.description,n.hint).any { it.trim() in setOf("搜索","搜索按钮","搜索联系人") } && n.box.top<s.height/2 }
    fun plus(s:Snapshot)=s.nodes.filter { n -> listOf(n.text,n.description).any { it.trim() in setOf("更多功能按钮","更多功能","加号","添加","+","更多") } && n.box.top>s.height/2 }
    fun phase(s:Snapshot):String {
        val labels=s.nodes.map { label(it) }
        if(labels.any { it.contains("挂断") } && labels.any { it.contains("摄像头") }) return "call"
        if(plus(s).isNotEmpty()) return "chat"
        if(labels.any { it.contains("视频通话") } && labels.any { it.contains("语音通话") }) return "video_menu"
        if(inputs(s).isNotEmpty() && (searches(s).isNotEmpty() || labels.any { it.contains("取消") })) return if(inputs(s).any { it.text.isNotBlank() && it.text!="搜索" }) "search_results" else "search_input"
        if(searches(s).isNotEmpty() || labels.any { it=="通讯录" }) return "find_contact"
        return "recover"
    }
    fun context(version:JSONObject?,s:Snapshot):JSONObject = JSONObject().put("version",version ?: JSONObject.NULL).put("current_phase",phase(s))
        .put("search_nodes",org.json.JSONArray(searches(s).map { it.id })).put("input_nodes",org.json.JSONArray(inputs(s).map { it.id }))
        .put("plus_nodes",org.json.JSONArray(plus(s).map { it.id }))
    fun target(d:Decision,s:Snapshot,fallback:Box?,enabled:Boolean):Box? {
        // Semantic grounding applies even when no workflow is enabled.
        if(d.action==Action.INPUT) {
            val candidates=inputs(s)
            val chosen=candidates.find { it.id==d.node } ?: candidates.singleOrNull()
            require(chosen!=null) { "输入位置无法确认：未找到唯一输入框，请重新观察或补充截图" }
            return chosen.box
        }
        if(!enabled) return fallback
        if(d.action==Action.SCROLL && phase(s) in setOf("find_contact","search_input","search_results")) error("流程要求优先搜索联系人，禁止逐屏滑动查找；请使用搜索入口")
        if(d.action==Action.CLICK && (d.instruction.contains("搜索") || d.instruction.contains("放大镜")) && !d.instruction.contains("结果")) {
            val candidates=searches(s).ifEmpty { inputs(s).filter { it.box.top<s.height/2 } }
            val exact=candidates.find { it.id==d.node } ?: candidates.singleOrNull()
            if(exact!=null) return exact.box
            require(d.node?.let { id -> s.nodes.find { it.id==id }?.let { label(it).isNotBlank() } }==true) { "搜索定位失败：目标是空白容器，缺少搜索控件证据" }
        }
        if(d.action==Action.CLICK && phase(s)=="chat") {
            val target=s.nodes.find { it.id==d.node }
            val candidates=plus(s)
            if(target?.let { label(it).contains("更多信息") }==true || (d.instruction.contains("更多") && fallback!=null && fallback.top<s.height/2)) {
                return candidates.singleOrNull()?.box ?: error("聊天页应点击输入栏旁加号，当前加号位置不明确")
            }
        }
        return fallback
    }
}
