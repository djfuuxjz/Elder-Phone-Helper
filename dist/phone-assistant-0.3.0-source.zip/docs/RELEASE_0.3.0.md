# V0.3.0 · 决策证据、执行与日志可视化

本版本修改程序实现和离线查看器，并保留同步期间新增的 13 项只读参数化高频任务流程。未连接真机；本地模拟测试通过不等于手机权限、微信或云端模型已完成实测。

## 主要变化

1. **目标解析**：仅 `target_node` 的空字符串、纯空白兼容为 Kotlin null。字符串 `"null"`、旧快照节点和不存在的节点仍会被拒绝。保留坐标边界、节点重叠、目标面积校验。提示词要求无节点时用 JSON null。
2. **诊断**：解析、目标定位、截图、网络、取消、过期响应、执行、完成验证分别记录。诊断包含 `stage/error_code/rule/expected/actual`，并关联 session、step、attempt、request、snapshot、模型内容及附件。手机展示简短原因，电脑保留详情。
3. **每次决策采集**：每次决策、重试都尝试截图；文本模型也保存本地截图。树读取前后及事件版本夹住截图采集，期间页面变化则废弃并重新观察。Android 不提供树和图的原子快照，这项一致性检查不能消除系统未报告的瞬时变化。截图失败保留明确错误和树引用，可以在稳定页面上继续文本判断。
4. **采集预算**：广度优先遍历，遍历上限 3000、深度上限 50；空容器不计入有效节点，最多保留 700 个有效节点，可点击/可编辑优先。记录遍历数、跳过空容器数、有效候选数、限制与截断原因。更深或未暴露给无障碍的控件仍可能缺失。
5. **查看器**：原图/节点叠加切换、短编号、悬停/点击详情、节点列表联动、单独的模型目标框、空容器/可点击/文字筛选、50%–250% 缩放、方向和越界检查、截断状态、原始 JSON。旧日志没有的新字段会显示未记录，不补造信息。
6. **打开应用**：模型可返回 `open_app` 和 `target_app`，必须使用本机查询到的可启动应用包；优先真实系统启动入口，验证前台包。验证失败时，仅在允许 GUI 的模式下回桌面寻找唯一可见同名图标点击一次；仍失败转人工。没有编造第三方 API、包名或 Deep Link，也不扫描其他桌面页猜图标。
7. **执行模式**：默认人工引导。可在“我的”勾选“允许自动点击和返回”；只支持经目标校验的点击与返回，输入和滚动明确转人工。打开应用默认可尝试系统入口；派发成功与页面变化、任务成功分别记录。页面变化仅证明发生变化，不宣称某个按钮的语义效果已达成；后续决策继续验证目标。
8. **操作观察**：记录 Android 实际报告的点击、滚动、输入变化、窗口/内容变化；收到返回键事件时单独记录。记录事件时间、应用、可匹配节点/区域、建议请求和前后快照。事件可能来自用户、应用自身或其他辅助服务，不能确定时标记来源不确定；自动操作也有独立的请求/回调。没有完整触摸轨迹，不根据页面变化虚构点击或返回。
9. **隐私和复盘**：输入事件不记输入值/按键文字；树中不保存可编辑字段值和密码字段文本。截图仍可能包含页面实际显示的隐私信息。成功复盘使用实际事件与证据，提示词明确不把未知来源和推测写成已确认人工操作。
10. **完成延迟**：200ms 轮询、截图隐藏等待由 250ms 调为 100ms；截图压缩、保存和日志写入离开主线程；取消旧请求后新请求不必等待同一个串行网络线程。完整目标恰好是“打开/启动某个已安装应用”时，可在当前稳定前台页面确认后直接提示；“打开应用并做某事”等复合目标仍需模型确认。模型完成需非空当前页面证据。成功提示不等待日志落盘或成功复盘。导出/清理会等待排队证据写入结束。

## 延迟测量

新版记录 `page_first_seen_at_ms`、`stable_wait_ms`、`capture_latency_ms`、`queue_latency_ms`、模型 `latency_ms`、`confirmed_at_ms`、`shown_at_ms`、`evidence_to_confirmation_ms` 和 `confirmation_to_display_ms`。

`page_first_seen_at_ms` 是程序第一次观察到页面候选的时间，不是物理画面变化的精确时间；模型任务的证据时间也不是独立视频标注。Android 无障碍窗口、动画和模型服务会影响总耗时。

当前 `adb devices -l` 没有已连接设备。因此**没有新版真机端到端延迟数值，也没有声称提升了某个百分比**。100ms/200ms 是代码配置，不是真机测量结果。用同设备、同目标分别测试旧版和新版，导出至少多次运行，再比较上述分项与人工标注时间。

## 手机验证

1. 本机新构建签名与已有 V0.2.0 APK 不同，**不能保证覆盖安装**。请先导出旧版日志和需要的流程；优先在备用设备测试，或使用原签名密钥重新构建。不要未经备份直接卸载旧版。
2. 安装 V0.3.0，启用无障碍服务，配置自己的模型。默认保持人工模式。
3. 测试“打开设置”：确认实际设置页出现后再成功；测试“打开设置并调大字体”：打开应用时不能提前成功。
4. 测试用户提供的空节点坐标样例；观察有效坐标能展示，越界、旧节点、节点坐标不重叠、整屏大框仍拒绝并说明原因。
5. 每步导出后检查 `snapshot_saved` 的树/图引用；文本模型应有本地图但 `screenshot_sent_to_model=false`。只有请求正文实际上传结束才记录 `request_body_sent`。
6. 开启自动点击/返回，使用无破坏性的测试页面；检查 `system_intent → 前台验证`，以及系统入口未验证时的 GUI/人工降级。输入与滚动目前仍人工完成。
7. 人工点击、滑动、输入和返回，核对 `behavior_observed` 与 `behavior_page_link`，确认不把系统事件来源猜成确定的用户，也不记录输入值。
8. 观察完成后提示及时出现；日志中的 `execution_result=dispatched_not_verified` 或 `guidance.executed=false` 不能当作任务成功。

## 电脑验证

从 `00_日常使用/日志查看器/index.html` 打开，导入含 `events.jsonl`、树 JSON 和图片的完整解压文件夹。

- 选一次请求，切换右侧“UI 节点叠加”；试用节点筛选、悬停、点击和列表联动。
- 橙框是模型/展示目标，蓝色虚线是手选节点，粉色框是 UI 节点；两种目标不互相替换。
- 调整缩放，检查同一节点仍对准区域；方向不匹配而缺少转换时应停止绘制并提示。
- 查看“过程与结果”中的诊断字段、执行方式、系统操作事件、页面验证和耗时；可切原始事件与 UI Tree JSON 对照。
- 旧日志原来没有截图/采集原因的步骤无法补回截图；新功能需用新版运行日志验证。

## 系统限制

安全窗口、无障碍权限、截图频率限制、后台启动限制、应用可见性、第三方控件未暴露节点等仍受 Android/厂商控制。系统未投递的返回手势不能完整记录。当前只发现并使用启动入口，没有承诺支持所有应用 Deep Link。自动输入/滚动未实现，保持明确人工降级。任意任务的语义完成仍依赖模型理解，证据门槛减少明显误报，不能保证模型永不误判。

## 主要改动文件

- `model/DecisionCodec.kt`、`Diagnostic.kt`、`ModelProvider.kt`、`RequestFailure.kt`、`RequestPacer.kt`。
- `observation/ScreenReader.kt`、`Screenshotter.kt`、`PageRules.kt`；`core/Data.kt`。
- `guidance/GuidanceController.kt`、`GuiExecutor.kt`、`TargetAppLauncher.kt`、`CompletionCheck.kt`、`SessionFlow.kt`。
- `logging/BehaviorRecorder.kt`、`EvidenceWork.kt`、`RunLog.kt`、`RunMetrics.kt`。
- `accessibility/GuideService.kt`、服务 XML、Manifest、`config/Settings.kt`、`ui/MainActivity.kt`、`DebugActivity.kt`。
- `workflow/WorkflowReview.kt`、`WorkflowStore.kt`；新增及调整相关测试。
- 查看器 `index.html/style.css/core.js/viewer.js`，新增 `geometry.js` 与几何/浏览器集成测试。

测试结果及可复现命令见 `docs/test-results/verification-0.3.0.md`。

## 接口依据

使用 Android 公开的 [AccessibilityService](https://developer.android.com/reference/android/accessibilityservice/AccessibilityService) 和 [AccessibilityEvent](https://developer.android.com/reference/android/view/accessibility/AccessibilityEvent)；截图、手势和键事件需要服务声明相应能力，最终可用性以设备授予情况为准。
