# V0.3.0 修改与新增文件

以下为相对开发工程的路径。源码、测试、说明及新交付包均同步；原有历史包未覆盖。

- `CHANGELOG.md`
- `README.md`
- `app/build.gradle.kts`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/cn/elder/assistant/accessibility/GuideService.kt`
- `app/src/main/java/cn/elder/assistant/config/Settings.kt`
- `app/src/main/java/cn/elder/assistant/core/Data.kt`
- `app/src/main/java/cn/elder/assistant/guidance/CompletionCheck.kt`
- `app/src/main/java/cn/elder/assistant/guidance/GuiExecutor.kt`
- `app/src/main/java/cn/elder/assistant/guidance/GuidanceController.kt`
- `app/src/main/java/cn/elder/assistant/guidance/SessionFlow.kt`
- `app/src/main/java/cn/elder/assistant/guidance/TargetAppLauncher.kt`
- `app/src/main/java/cn/elder/assistant/logging/BehaviorRecorder.kt`
- `app/src/main/java/cn/elder/assistant/logging/EvidenceWork.kt`
- `app/src/main/java/cn/elder/assistant/logging/RunLog.kt`
- `app/src/main/java/cn/elder/assistant/logging/RunMetrics.kt`
- `app/src/main/java/cn/elder/assistant/model/DecisionCodec.kt`
- `app/src/main/java/cn/elder/assistant/model/Diagnostic.kt`
- `app/src/main/java/cn/elder/assistant/model/ModelProvider.kt`
- `app/src/main/java/cn/elder/assistant/model/RequestFailure.kt`
- `app/src/main/java/cn/elder/assistant/model/RequestPacer.kt`
- `app/src/main/java/cn/elder/assistant/observation/PageRules.kt`
- `app/src/main/java/cn/elder/assistant/observation/ScreenReader.kt`
- `app/src/main/java/cn/elder/assistant/observation/Screenshotter.kt`
- `app/src/main/java/cn/elder/assistant/ui/DebugActivity.kt`
- `app/src/main/java/cn/elder/assistant/ui/MainActivity.kt`
- `app/src/main/java/cn/elder/assistant/workflow/WorkflowReview.kt`
- `app/src/main/java/cn/elder/assistant/workflow/WorkflowStore.kt`
- `app/src/main/res/xml/accessibility.xml`
- `app/src/test/java/cn/elder/assistant/BehaviorRecorderTest.kt`
- `app/src/test/java/cn/elder/assistant/CustomControllerTest.kt`
- `app/src/test/java/cn/elder/assistant/DecisionDiagnosticsTest.kt`
- `app/src/test/java/cn/elder/assistant/EvidenceWorkTest.kt`
- `app/src/test/java/cn/elder/assistant/ObservationEvidenceTest.kt`
- `app/src/test/java/cn/elder/assistant/PipelineDiagnosticsTest.kt`
- `app/src/test/java/cn/elder/assistant/ReturnGuidanceTest.kt`
- `app/src/test/java/cn/elder/assistant/Revision014Test.kt`
- `dist/SHA256SUMS-0.3.0.txt`
- `dist/phone-assistant-0.3.0-debug.apk`
- `dist/phone-assistant-0.3.0-source.zip`
- `dist/手机助手日志查看器-0.3.0.zip`
- `docs/RELEASE_0.3.0.md`
- `docs/design/ui-0.3.0/debug.png`
- `docs/design/ui-0.3.0/mine.png`
- `docs/design/ui-0.3.0/overlay-large-font.png`
- `docs/design/ui-0.3.0/overlay.png`
- `docs/design/ui-0.3.0/task-large-font-small-screen.png`
- `docs/design/ui-0.3.0/task.png`
- `docs/design/ui-0.3.0/workflow.png`
- `docs/test-results/android-verification-0.3.0.txt`
- `docs/test-results/verification-0.3.0.md`
- `docs/test-results/viewer-core-0.3.0.txt`
- `docs/test-results/viewer-integration-0.3.0.txt`
- `日志查看器/core.js`
- `日志查看器/geometry.js`
- `日志查看器/index.html`
- `日志查看器/style.css`
- `日志查看器/test-geometry.cjs`
- `日志查看器/test-integration.cjs`
- `日志查看器/viewer.js`
- `日志查看器/使用说明.md`

- `docs/CHANGED_FILES_0.3.0.md`（本清单）

并发新增的 WorkflowCatalog、WorkflowGuide、WorkflowActivity、WorkflowCatalogTest、流程库说明与产品需求保留；它们也已进入本次源码快照。桌面项目外层目录说明及日常使用快捷入口同时指向 V0.3.0。
