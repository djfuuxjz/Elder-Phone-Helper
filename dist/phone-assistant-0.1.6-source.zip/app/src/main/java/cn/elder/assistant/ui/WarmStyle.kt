package cn.elder.assistant.ui

import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.view.View
import android.widget.TextView
import android.widget.Button

/** Presentation only: shared palette and decorative companion. */
object WarmStyle {
    const val background = 0xFFFFF8ED.toInt()
    const val ink = 0xFF382A20.toInt()
    const val accent = 0xFFFFD58A.toInt()
    fun dp(c:Context,n:Int)=(n*c.resources.displayMetrics.density).toInt()
    fun surface(c:Context,color:Int=0xFFFFEFDA.toInt(),radius:Int=20)=GradientDrawable().apply {
        setColor(color);cornerRadius=dp(c,radius).toFloat()
        setStroke(dp(c,1),0xFFE8CDA9.toInt())
    }
    fun text(v:TextView) { v.setTextColor(ink);v.setLineSpacing(dp(v.context,3).toFloat(),1.08f) }
    fun button(v:Button,primary:Boolean=false) {
        text(v);v.textSize=20f;v.isAllCaps=false;v.minHeight=dp(v.context,60)
        v.setPadding(dp(v.context,16),dp(v.context,12),dp(v.context,16),dp(v.context,12))
        v.background=RippleDrawable(ColorStateList.valueOf(0x227B4B1F),surface(v.context,if(primary) accent else 0xFFFFEFDA.toInt()),null)
        v.layoutParams=android.widget.LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(v.context,8);bottomMargin=dp(v.context,8) }
    }
}

/** Native vector drawing stays crisp at every font/display size; never a focus target. */
class CatView(context:Context):View(context) {
    init { importantForAccessibility=IMPORTANT_FOR_ACCESSIBILITY_NO;isFocusable=false }
    private val p=Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeJoin=Paint.Join.ROUND;strokeCap=Paint.Cap.ROUND }
    private val cat=Path().apply { moveTo(37f,55f);quadTo(26f,3f,48f,15f);lineTo(70f,33f);quadTo(90f,27f,110f,33f);lineTo(135f,13f);quadTo(155f,6f,145f,58f);cubicTo(178f,116f,8f,117f,37f,55f);close() }
    override fun onDraw(canvas:Canvas) {
        super.onDraw(canvas)
        val save=canvas.save();val scale=minOf(width/180f,height/120f)
        canvas.translate((width-180*scale)/2,(height-120*scale)/2);canvas.scale(scale,scale)
        p.color=0xFFFFE4AC.toInt();canvas.drawOval(12f,22f,168f,117f,p)
        p.color=0xFFFFFEF8.toInt();canvas.drawPath(cat,p)
        p.color=0xFF875634.toInt();p.style=Paint.Style.STROKE;p.strokeWidth=3.5f;canvas.drawPath(cat,p)
        canvas.drawArc(59f,55f,74f,68f,195f,150f,false,p);canvas.drawArc(106f,55f,121f,68f,195f,150f,false,p)
        canvas.drawArc(77f,68f,90f,80f,0f,170f,false,p);canvas.drawArc(90f,68f,103f,80f,10f,170f,false,p)
        p.style=Paint.Style.FILL;p.color=0xFFF0B89C.toInt();canvas.drawOval(47f,72f,64f,80f,p);canvas.drawOval(116f,72f,133f,80f,p)
        p.color=0xFF875634.toInt();canvas.drawCircle(90f,68f,3f,p)
        p.color=0xFFFFFEF8.toInt();canvas.drawOval(48f,93f,75f,111f,p);canvas.drawOval(105f,93f,132f,111f,p)
        canvas.restoreToCount(save)
    }
}
