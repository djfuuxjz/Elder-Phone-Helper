package cn.elder.assistant

import cn.elder.assistant.guidance.*
import cn.elder.assistant.core.*
import org.junit.Assert.*
import org.junit.Test

class FlowTest {
    private fun flow()=SessionFlow().apply { start();observe("home") }
    @Test fun newPageStartsNewStep() { val f=flow();assertEquals(1,f.step);assertFalse(f.observe("home"));assertTrue(f.observe("wechat"));assertEquals(2,f.step) }
    @Test fun repeatedEventsDoNotCreateRequestLoop() { val f=flow();val t=f.request();f.responded(t,Phase.WAITING_USER);repeat(100) { assertFalse(f.observe("home")) };assertEquals(1,f.attempt) }
    @Test fun pageChangeInvalidatesInflightResponse() { val f=flow();val t=f.request();f.observe("wrong_chat");assertFalse(f.accepts(t));assertFalse(f.responded(t,Phase.WAITING_USER)) }
    @Test fun stopInvalidatesResponse() { val f=flow();val t=f.request();f.finish(Phase.STOPPED);assertFalse(f.accepts(t));assertFalse(f.active) }
    @Test fun restartNeverAcceptsOldSessionResponse() { val f=flow();val t=f.request();f.finish(Phase.STOPPED);f.start();f.observe("home");f.request();assertFalse(f.accepts(t)) }
    @Test fun supplementalImageCountsAsNewAttemptSameStep() { val f=flow();val t=f.request();f.responded(t,Phase.OBSERVING);val next=f.request();assertEquals(2,next.attempt);assertEquals(t.step,next.step) }
    @Test(expected=IllegalStateException::class) fun concurrentRequestsRejected() { val f=flow();f.request();f.request() }
    @Test(expected=IllegalStateException::class) fun fourthAutomaticAttemptRejected() { val f=flow();repeat(3) { val t=f.request();f.responded(t,Phase.OBSERVING) };f.request() }
    @Test fun manualRetryInvalidatesOldTokenAndStartsStep() { val f=flow();val t=f.request();f.pause();f.retry();val n=f.request();assertFalse(f.accepts(t));assertEquals(2,n.step);assertEquals(1,n.attempt) }
    @Test fun pausedFlowCannotAutoResumeFromEvents() { val f=flow();f.pause();assertFalse(f.observe("other"));assertEquals(Phase.NEEDS_ATTENTION,f.phase) }
    @Test fun completionIsTerminal() { val f=flow();f.finish(Phase.COMPLETED);assertFalse(f.observe("home"));assertFalse(f.active) }
    private fun decision()=Decision("video_call_outgoing",Action.COMPLETE,null,null,"已发起视频通话",0.98,true,listOf("女儿","正在呼叫","视频通话"))
    private fun page(texts:List<String>)=Snapshot("s","com.tencent.mm",1,1080,2400,texts.mapIndexed { i,t -> UiNode("n$i",t,"","TextView",false,Box(0,100+i*50,300,150+i*50)) },0)
    @Test fun contactPageIsNotComplete() { assertFalse(CompletionCheck.treeConfirms(page(listOf("女儿","发消息","视频通话")),decision())) }
    @Test fun videoMenuIsNotComplete() { assertFalse(CompletionCheck.treeConfirms(page(listOf("女儿","视频通话","语音通话","取消")),decision())) }
    @Test fun wrongRecipientIsNotComplete() { assertFalse(CompletionCheck.treeConfirms(page(listOf("张三","视频通话","正在呼叫","挂断")),decision())) }
    @Test fun actualCallEvidenceCanComplete() { assertTrue(CompletionCheck.treeConfirms(page(listOf("女儿","视频通话","等待对方接受邀请","取消")),decision())) }
    @Test fun anotherApplicationCannotComplete() { assertFalse(CompletionCheck.treeConfirms(page(listOf("女儿","视频通话","正在呼叫","挂断")).copy(packageName="fake"),decision())) }
    @Test fun suggestionCannotComplete() { assertFalse(CompletionCheck.treeConfirms(page(listOf("女儿","视频通话","正在呼叫","挂断")),decision().copy(completed=false,action=Action.CLICK))) }
    @Test fun incompleteVisualEvidenceCannotComplete() { assertFalse(CompletionCheck.visualCandidate(decision().copy(evidence=listOf("女儿"))));assertFalse(CompletionCheck.visualCandidate(decision().copy(confidence=0.8)));assertTrue(CompletionCheck.visualCandidate(decision())) }
    @Test(expected=IllegalArgumentException::class) fun wrongChatCannotGuideVideoCall() { RecipientGuard.check(page(listOf("张三","视频通话")),decision().copy(action=Action.CLICK,completed=false,instruction="请点击视频通话"),false) }
    @Test fun correctChatCanGuideVideoCall() { RecipientGuard.check(page(listOf("女儿","视频通话")),decision().copy(action=Action.CLICK,completed=false,instruction="请点击视频通话"),false) }
    @Test(expected=IllegalArgumentException::class) fun modelEvidenceAloneWithoutImageCannotAuthorizeCall() { RecipientGuard.check(page(listOf("视频通话")),decision().copy(action=Action.CLICK,completed=false,instruction="请点击视频通话"),false) }
}
