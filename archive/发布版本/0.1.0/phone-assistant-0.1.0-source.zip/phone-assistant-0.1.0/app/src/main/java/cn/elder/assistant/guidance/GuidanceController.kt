package cn.elder.assistant.guidance

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import cn.elder.assistant.config.Settings
import cn.elder.assistant.core.*
import cn.elder.assistant.logging.RunLog
import cn.elder.assistant.model.*
import cn.elder.assistant.observation.*
import cn.elder.assistant.overlay.GuideOverlay
import cn.elder.assistant.speech.Speaker
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

class GuidanceController(private val service:AccessibilityService) {
    private val handler=Handler(Looper.getMainLooper())
    private val worker=Executors.newSingleThreadExecutor()
    private val reader=ScreenReader(service)
    private val screenshots=Screenshotter(service,reader,worker)
    private val overlay=GuideOverlay(service,{ stop() },{ retry() })
    private val stable=StablePage()
    private val epoch=PageEpoch()
    private var lastStructure:String?=null
    private val flow=SessionFlow()
    private var log:RunLog?=null
    private var provider:ModelProvider?=null
    private var speaker:Speaker?=null
    private var lastProgress=0L
    private val timing=RunTiming()
    private var stepStarted=0L
    private var needImage=false
    private var visualCandidate:String?=null
    private val context=mutableListOf<String>()
    private var key=""
    private var endpoint=""
    private var model=""
    private var vision=true
    private var closed=false
    private val homePackage=service.packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),0)?.activityInfo?.packageName
    private val ticker=object:Runnable { override fun run() { if(flow.active && !closed) { runCatching { poll() }.onFailure { attention(it.message ?: "读取页面失败") }; handler.postDelayed(this,600) } } }
    fun start() {
        if(flow.active || closed) return
        try {
            val cfg=Settings(service);key=cfg.apiKey();endpoint=cfg.endpoint;model=cfg.model;vision=cfg.vision
            require(key.isNotBlank()) { "请先在我的页面填写模型密钥" }
            log=RunLog(File(service.filesDir,"runs"),listOf(key))
            flow.start();context.clear();stable.reset();epoch.reset();lastStructure=null;needImage=false;visualCandidate=null
            timing.reset(AppRuntime.debugWaitForStart)
            AppRuntime.debugWaitForStart=false
            lastProgress=SystemClock.elapsedRealtime();stepStarted=lastProgress
            AppRuntime.active=true
            logEvent("start",JSONObject().put("model",model).put("provider",endpoint).put("prompt_version",TaskSpec.PROMPT_VERSION)
                .put("device",android.os.Build.MODEL).put("android",android.os.Build.VERSION.RELEASE).put("wait_for_start",timing.waiting))
            speaker=Speaker(service) { reason -> handler.post { if(flow.active) logEvent("tts_error",JSONObject().put("error",reason)) } }
            if(timing.waiting) {
                AppRuntime.status="请准备测试起点，再点从当前页开始"
                overlay.show(AppRuntime.status,retry=true,retryLabel="从当前页开始")
            } else show("请您回到桌面，或打开微信")
            handler.post(ticker)
        } catch(e:Exception) { if(flow.active) stop(Phase.FAILED);AppRuntime.status=e.message ?: "无法开始任务" }
    }
    private fun poll() {
        if(flow.phase==Phase.NEEDS_ATTENTION || timing.waiting) return
        val now=SystemClock.elapsedRealtime()
        val elapsed=timing.elapsed(now)
        if(elapsed!=null && elapsed>300000) { attention("本次引导已等待较久，请停止后重新开始");return }
        if(elapsed!=null && now-lastProgress>60000) { attention("暂时没有看到页面变化，请重试或停止");return }
        val s=reader.capture() ?: run { overlay.hide();speaker?.cancel();provider?.cancel();return }
        if(s.packageName !in setOf("com.tencent.mm",homePackage)) {
            if(flow.fingerprint!=null) attention("请先回到微信或桌面，再点重试")
            return
        }
        val structure=s.fingerprint
        if(structure!=lastStructure) epoch.trackingVisual=s.nodes.none { it.text.isNotBlank() || it.description.isNotBlank() }
        val currentKey=epoch.key(structure)
        // Remove stale guidance immediately, before the debounce window finishes.
        if(flow.fingerprint!=null && currentKey!=flow.fingerprint) { overlay.hide();speaker?.cancel();provider?.cancel() }
        if(!stable.offer(currentKey,now)) return
        val first=timing.elapsed(now)==null
        if(!timing.observe(now)) return
        if(first) logEvent("measurement_start",JSONObject().put("snapshot_id",s.id).put("page",s.packageName))
        if(flow.observe(currentKey)) {
            lastStructure=structure;needImage=epoch.trackingVisual;visualCandidate=null;lastProgress=now;stepStarted=now;provider?.cancel();stable.reset()
            logEvent("observation",JSONObject().put("step",flow.step).put("snapshot_id",s.id).put("page",s.packageName))
        }
        if(flow.phase in setOf(Phase.OBSERVING,Phase.VERIFYING)) dispatch(s)
    }
    private fun dispatch(s:Snapshot) {
        val sentEpoch=epoch.version
        val token=try { flow.request() } catch(e:Exception) { attention(e.message ?: "请求次数过多");return }
        val thisLog=log ?: return
        val requestId="${thisLog.id}_${token.step}_${token.attempt}"
        val treeRef=try { thisLog.artifact("${requestId}_tree.json",s.json().toString(2).toByteArray()) }
            catch(e:Exception) { attention(e.message ?: "页面快照保存失败");return }
        show("正在看页面，请稍候",speak=false)
        val done:(Result<ByteArray?>)->Unit = done@{ imageResult ->
            if(!flow.accepts(token)) return@done
            if(sentEpoch!=epoch.version || !SnapshotConsistency.matches(s,reader.capture())) { flow.responded(token,Phase.OBSERVING); stable.reset();return@done }
            val image=imageResult.getOrElse {
                logEvent("capture_error",JSONObject().put("step",token.step).put("attempt",token.attempt).put("snapshot_id",s.id)
                    .put("ui_tree_ref",treeRef).put("error",it.message ?: "截图失败"))
                attention(it.message ?: "截图失败");return@done
            }
            try {
                val imageRef=image?.let { thisLog.artifact("${requestId}.jpg",it) }
                val p=DeepSeekProvider(endpoint,model,key,vision);provider=p
                val body=p.body(ModelInput(thisLog.id,token.step,token.attempt,s,context.toList(),image))
                val logged=JSONObject(body.toString())
                if(imageRef!=null) logged.getJSONArray("messages").getJSONObject(1).getJSONArray("content").getJSONObject(1)
                    .getJSONObject("image_url").put("url","local:$imageRef")
                val base=JSONObject().put("step",token.step).put("attempt",token.attempt).put("request_id",requestId)
                    .put("snapshot_id",s.id).put("ui_tree_ref",treeRef).put("screenshot_ref",imageRef ?: JSONObject.NULL)
                    .put("screenshot_reason",if(image==null) "UI Tree 优先" else "补充视觉定位/完成确认")
                thisLog.event("request_prepared",JSONObject(base.toString()).put("input",logged).put("model",model))
                worker.execute {
                    var requested:Long?=null
                    val result=runCatching { p.execute(body) {
                        requested=SystemClock.elapsedRealtime()
                        thisLog.event("request",JSONObject(base.toString()).put("input",logged).put("model",model))
                    } }
                    val latency=requested?.let { SystemClock.elapsedRealtime()-it }
                    handler.post {
                        val event=JSONObject(base.toString())
                        if(latency!=null) event.put("latency_ms",latency)
                        result.fold({ r -> event.put("output_raw",r.raw).put("content",r.content) },{ e ->
                            event.put("error",if(e is ModelFailure) e.code else e.javaClass.simpleName)
                            if(e is ModelFailure) event.put("output_raw",e.raw)
                        })
                        if(!safeEvent(thisLog,if(requested==null) "request_cancelled" else "response",event)) return@post
                        if(!flow.accepts(token)) { safeEvent(thisLog,"discarded",JSONObject(base.toString()).put("reason","会话/页面版本已失效"));return@post }
                        AppRuntime.modelStatus=if(result.isSuccess) "最近一次模型请求成功" else "最近一次模型请求失败，请查看 Debug"
                        if(sentEpoch!=epoch.version || !SnapshotConsistency.matches(s,reader.capture())) {
                            flow.responded(token,Phase.OBSERVING);overlay.hide();stable.reset()
                            safeEvent(thisLog,"discarded",JSONObject(base.toString()).put("reason","响应到达时页面已变化"));return@post
                        }
                        result.fold({ r -> applyDecision(token,s,r.content,image!=null,base) },{ e ->
                            val message=when((e as? ModelFailure)?.code) { "HTTP_401" -> "模型密钥无效，请停止后在我的页面检查"; "HTTP_429" -> "模型服务繁忙或额度不足，请稍后重试"; else -> "模型调用失败，请检查网络和配置后重试" }
                            attention(message)
                        })
                    }
                }
            } catch(e:Exception) { attention(e.message ?: "模型请求准备失败") }
        }
        if(needImage || s.nodes.none { it.text.isNotBlank() || it.description.isNotBlank() }) {
            if(!vision) { attention("当前页面需要图片理解，请停止后启用支持图片的模型");return }
            epoch.trackingVisual=true
            screenshots.capture(s,{ overlay.hide() },{ !closed && flow.accepts(token) }) { result -> done(result.map { it }) }
        } else done(Result.success(null))
    }
    private fun applyDecision(token:RequestToken,s:Snapshot,raw:String,hasImage:Boolean,base:JSONObject) {
        try {
            val d=DecisionCodec.parse(raw)
            logEvent("decision",JSONObject(base.toString()).put("output_parsed",JSONObject(raw)))
            if(d.action==Action.NEED_SCREENSHOT) {
                if(hasImage) { attention("有截图仍无法确定下一步，请重试");return }
                needImage=true;flow.responded(token,Phase.OBSERVING);return
            }
            val target=DecisionCodec.target(d,s)
            RecipientGuard.check(s,d,hasImage)
            if(d.completed) {
                val treeConfirmed=CompletionCheck.treeConfirms(s,d)
                val candidate=CompletionCheck.visualCandidate(d) && s.packageName=="com.tencent.mm"
                if(treeConfirmed || (hasImage && candidate && visualCandidate==s.fingerprint)) {
                    logEvent("completed_evidence",JSONObject(base.toString()).put("evidence",org.json.JSONArray(d.evidence)).put("method",if(treeConfirmed) "ui_tree" else "two_observations_with_image"))
                    stop(Phase.COMPLETED);return
                }
                if(candidate && vision && visualCandidate==null) {
                    visualCandidate=s.fingerprint;needImage=true;flow.responded(token,Phase.VERIFYING);return
                }
                attention("还不能确认已向女儿发起视频通话，请查看当前页面后重试");return
            }
            visualCandidate=null
            if(d.action==Action.BLOCKED) { attention(d.instruction);return }
            flow.responded(token,Phase.WAITING_USER);lastProgress=SystemClock.elapsedRealtime()
            context.add("${d.state}：${d.instruction}"); if(context.size>8) context.removeAt(0)
            show(d.instruction,if(d.action==Action.CLICK) target else null)
            logEvent("guidance",JSONObject(base.toString()).put("instruction",d.instruction).put("target",target?.json() ?: JSONObject.NULL)
                .put("guidance_latency_ms",SystemClock.elapsedRealtime()-stepStarted))
        } catch(e:Exception) {
            logEvent("invalid_decision",JSONObject(base.toString()).put("error",e.message ?: "解析失败"))
            if(!hasImage && vision && flow.attempt<3) { needImage=true;flow.responded(token,Phase.OBSERVING) }
            else attention("未找到可靠的操作位置，请重试")
        }
    }
    fun retry() {
        if(!flow.active) return
        if(timing.waiting) {
            timing.release();stable.reset();logEvent("preparation_finished");show("正在读取测试起点",speak=false);return
        }
        provider?.cancel();flow.retry();stable.reset();needImage=false;visualCandidate=null;lastProgress=SystemClock.elapsedRealtime();stepStarted=lastProgress
        logEvent("manual_retry");show("正在重新看页面",speak=false)
    }
    fun pageEvent(packageName:String) {
        if(flow.active && packageName in setOf("com.tencent.mm",homePackage)) epoch.pageEvent()
    }
    private fun attention(reason:String) { if(!flow.active) return;provider?.cancel();flow.pause();logEvent("attention",JSONObject().put("error",reason));show(reason,retry=true) }
    private fun show(text:String,target:Box?=null,retry:Boolean=false,speak:Boolean=true) {
        AppRuntime.status=text
        overlay.show(text,target,retry)
        if(speak) speaker?.speak(text)
    }
    private fun logEvent(type:String,data:JSONObject=JSONObject()) { log?.let { safeEvent(it,type,data) } }
    private fun safeEvent(destination:RunLog,type:String,data:JSONObject):Boolean = try { destination.event(type,data);true } catch(e:Exception) {
        // An old response may arrive after its run was cleared. It must not kill a newer session.
        if(destination===log && flow.active) {
            flow.finish(Phase.FAILED);provider?.cancel();overlay.hide();speaker?.close();speaker=null;handler.removeCallbacks(ticker)
            AppRuntime.active=false;AppRuntime.status="日志保存失败，请在 Debug 清理空间后重新开始"
        }
        false
    }
    fun stop(result:Phase=Phase.STOPPED) {
        if(!flow.active) return
        logEvent("end",JSONObject().put("result",result.name).put("duration_ms",timing.elapsed(SystemClock.elapsedRealtime()) ?: JSONObject.NULL))
        flow.finish(result);provider?.cancel();provider=null;handler.removeCallbacks(ticker);overlay.hide();speaker?.close();speaker=null;key=""
        AppRuntime.active=false;AppRuntime.status=if(result==Phase.COMPLETED) "已向女儿发起视频通话" else "引导已停止，可重新开始"
        if(result==Phase.COMPLETED) android.widget.Toast.makeText(service,AppRuntime.status,android.widget.Toast.LENGTH_LONG).show()
    }
    fun close() { stop(Phase.FAILED);closed=true;handler.removeCallbacksAndMessages(null);worker.shutdown();overlay.hide() }
}
