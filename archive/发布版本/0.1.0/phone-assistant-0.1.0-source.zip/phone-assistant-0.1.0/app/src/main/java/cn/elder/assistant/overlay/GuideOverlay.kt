package cn.elder.assistant.overlay

import android.accessibilityservice.AccessibilityService
import android.graphics.*
import android.view.*
import android.widget.*
import cn.elder.assistant.core.Box
import cn.elder.assistant.observation.Coordinates

class GuideOverlay(private val service: AccessibilityService, private val onStop:()->Unit, private val onRetry:()->Unit) {
    private val wm=service.getSystemService(WindowManager::class.java)
    private var highlight: View?=null
    private var card: View?=null
    companion object {
        fun highlightFlags() = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        fun controlFlags() = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
    }
    fun show(instruction:String, target:Box?=null, retry:Boolean=false, retryLabel:String="重试") {
        hide()
        try {
            if(target!=null) {
                val view=object:View(service) {
                    private val dim=Paint().apply { color=0x66000000 }
                    private val hole=Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode=PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
                    private val ring=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(255,214,64); style=Paint.Style.STROKE; strokeWidth=dp(4).toFloat() }
                    private val origin=IntArray(2)
                    private val rect=RectF()
                    override fun onDraw(canvas:Canvas) {
                        getLocationOnScreen(origin)
                        rect.set((target.left-origin[0]).toFloat(),(target.top-origin[1]).toFloat(),(target.right-origin[0]).toFloat(),(target.bottom-origin[1]).toFloat())
                        canvas.drawRect(0f,0f,width.toFloat(),height.toFloat(),dim)
                        canvas.drawRoundRect(rect,12f,12f,hole); canvas.drawRoundRect(rect,12f,12f,ring)
                    }
                }.apply { setLayerType(View.LAYER_TYPE_SOFTWARE,null); importantForAccessibility=View.IMPORTANT_FOR_ACCESSIBILITY_NO }
                val lp=WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,highlightFlags(),PixelFormat.TRANSLUCENT)
                lp.gravity=Gravity.TOP or Gravity.START; lp.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                wm.addView(view,lp); highlight=view
            }
            val layout=LinearLayout(service).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),dp(8),dp(12),dp(8)); setBackgroundColor(Color.rgb(255,253,242)) }
            layout.addView(TextView(service).apply { text=instruction; textSize=20f; setTextColor(Color.rgb(28,52,41)); maxLines=4 })
            val row=LinearLayout(service)
            row.addView(Button(service).apply { text="停止"; textSize=18f; minHeight=dp(48); setOnClickListener { onStop() } },LinearLayout.LayoutParams(0,-2,1f))
            if(retry) row.addView(Button(service).apply { text=retryLabel; textSize=18f; minHeight=dp(48); setOnClickListener { onRetry() } },LinearLayout.LayoutParams(0,-2,1f))
            layout.addView(row)
            val screen=wm.maximumWindowMetrics.bounds
            val lp=WindowManager.LayoutParams(minOf(dp(340),screen.width()-dp(24)),-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,controlFlags(),PixelFormat.TRANSLUCENT)
            lp.gravity=(if(Coordinates.cardAtTop(target,screen.height())) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
            lp.y=dp(24)
            wm.addView(layout,lp); card=layout
            // Actual card bounds, including large font layout, must never cover the target.
            layout.post {
                if(card===layout && target!=null) {
                    val xy=IntArray(2); layout.getLocationOnScreen(xy)
                    if(Box(xy[0],xy[1],xy[0]+layout.width,xy[1]+layout.height).overlaps(target)) {
                        wm.removeView(layout); card=null // highlighter stays touch-through; stop remains in App
                    }
                }
            }
        } catch(e:RuntimeException) { hide(); throw e }
    }
    fun hide() { highlight?.let { if(it.isAttachedToWindow) wm.removeViewImmediate(it) }; card?.let { if(it.isAttachedToWindow) wm.removeViewImmediate(it) }; highlight=null; card=null }
    private fun dp(n:Int)=(n*service.resources.displayMetrics.density).toInt()
}
