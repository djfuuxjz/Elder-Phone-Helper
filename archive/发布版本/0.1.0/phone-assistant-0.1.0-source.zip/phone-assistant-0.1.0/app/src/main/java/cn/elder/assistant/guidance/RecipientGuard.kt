package cn.elder.assistant.guidance

import cn.elder.assistant.core.*

object RecipientGuard {
    fun check(s:Snapshot,d:Decision,hasImage:Boolean) {
        if(d.action!=Action.CLICK || s.packageName!="com.tencent.mm") return
        val target=s.nodes.find { it.id==d.node }
        val words="${target?.text.orEmpty()} ${target?.description.orEmpty()} ${d.instruction}"
        if(!words.contains("视频通话") && !words.contains("视频电话")) return
        val visibleRecipient=s.nodes.any { (it.text.trim()=="女儿" || it.description.trim()=="女儿") && it.box.top<s.height*0.45 }
        val visualRecipient=hasImage && d.confidence>=0.9 && d.evidence.any { it=="女儿" }
        require(visibleRecipient || visualRecipient) { "发起视频前无法确认当前联系人是女儿" }
    }
}
